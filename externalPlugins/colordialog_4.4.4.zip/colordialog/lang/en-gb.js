﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'en-gb', {
	clear: 'Clear',
	highlight: 'Highlight',
	options: 'Colour Options',
	selected: 'Selected Colour',
	title: 'Select colour'
} );
